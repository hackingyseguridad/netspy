# encoding: UTF-8
=begin

BETTERCAP

Author : Simone 'evilsocket' Margaritelli
Email  : evilsocket@gmail.com
Blog   : https://www.evilsocket.net/

This project is released under the GPL 3 license.

=end

module BetterCap

class SpoofOptions
  # Name of the spoofer to use.
  attr_accessor :spoofer
  # If true half duplex mode is enabled.
  attr_accessor :half_duplex
  # If true, bettercap won't forward packets for any target, causing
  # connections to be killed.
  attr_accessor :kill

  def initialize
    @spoofer     = 'ARP'
    @half_duplex = true
    @kill        = false
  end

  def parse!( ctx, opts )
    opts.separator ""
    opts.separator "SPOOFING:".bold
    opts.separator ""

    opts.on( '-S', '--spoofer NAME', "Spoofer module to use, available: #{Spoofers::Base.available.map{|x| x.yellow }.join(', ')} - default: #{@spoofer.yellow} for IPv4 and #{'NDP'.yellow} for IPv6." ) do |v|
      @spoofer = v
    end

    opts.on( '--no-spoofing', "Disable spoofing, alias for #{'--spoofer NONE'.yellow}." ) do
      @spoofer = 'NONE'
    end

    opts.on( '--full-duplex', 'Enable full-duplex MITM, this will make bettercap attack both the target(s) and the router.' ) do
      @half_duplex = false
    end

    opts.on( '--kill', 'Instead of forwarding packets, this switch will make targets connections to be killed.' ) do
      @kill = true
    end
  end

  # Return true if a spoofer module was specified, otherwise false.
  def enabled?
    @spoofer.upcase != 'NONE'
  end

  # Change default ARP with NDP spoofer in case the target endpoint uses IPv6.
  def calibrate_default_spoofer(ctx)
    if ctx.options.core.use_ipv6
      @spoofer = 'NDP'
    end
  end


  # Parse spoofers and return a list of BetterCap::Spoofers objects. Raise a
  # BetterCap::Error if an invalid spoofer name was specified.
  def parse_spoofers(ctx)
    valid = []
    calibrate_default_spoofer(ctx)
    @spoofer.split(",").each do |module_name|
      valid << Spoofers::Base.get_by_name( module_name )
    end
    valid
  end

end

end
